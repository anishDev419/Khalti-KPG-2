from django.apps import AppConfig


class ConnectipsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'connectips'
